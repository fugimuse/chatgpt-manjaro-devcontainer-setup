# Node + Frontend (DevPod + Podman)

Base: `node:lts-bookworm`

Includes:
- Node toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id node-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh node-pod
```
