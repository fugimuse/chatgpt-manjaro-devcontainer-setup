# Java + Frontend (DevPod + Podman)

Base: `eclipse-temurin:21-jdk`

Includes:
- Java toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id java-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh java-pod
```
