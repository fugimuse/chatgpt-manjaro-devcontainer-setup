# Dotnet + Frontend (DevPod + Podman)

Base: `mcr.microsoft.com/dotnet/sdk:8.0-bookworm-slim`

Includes:
- Dotnet toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id dotnet-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh dotnet-pod
```
