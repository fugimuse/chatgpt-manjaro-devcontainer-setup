# DevPod + Podman Templates

See **SETUP.md** for quick start instructions.

Templates:
- node
- python
- go
- java
- dotnet
- ruby
- php
- rust
- elixir
- deno
