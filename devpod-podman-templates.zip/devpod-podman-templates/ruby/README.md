# Ruby + Frontend (DevPod + Podman)

Base: `ruby:3.3-bookworm`

Includes:
- Ruby toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id ruby-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh ruby-pod
```
