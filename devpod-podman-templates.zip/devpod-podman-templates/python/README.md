# Python + Frontend (DevPod + Podman)

Base: `python:3.12-bookworm`

Includes:
- Python toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id python-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh python-pod
```
