# Elixir + Frontend (DevPod + Podman)

Base: `hexpm/elixir:1.17.2-erlang-27.0.1-debian-bookworm-20240903`

Includes:
- Elixir toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id elixir-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh elixir-pod
```
