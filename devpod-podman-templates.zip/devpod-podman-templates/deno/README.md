# Deno + Frontend (DevPod + Podman)

Base: `denoland/deno:alpine-1.46.3`

Includes:
- Deno toolchain
- Node.js LTS + pnpm, yarn
- Frontend tooling: vite, sass, eslint, prettier
- Non-root `dev` user with sudo
- Podman-friendly `Containerfile` + `devcontainer.json`

## Usage
```bash
devpod up --id deno-pod --provider podman .
```
Then open the folder in your editor, or:
```bash
devpod ssh deno-pod
```
